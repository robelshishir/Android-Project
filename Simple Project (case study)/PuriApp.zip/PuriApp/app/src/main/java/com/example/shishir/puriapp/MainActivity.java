package com.example.shishir.puriapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView countepuri,addprice,showdetails;
    int increaser=0;
    int totalpuri,totalprice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        countepuri = (TextView) findViewById(R.id.puri_count);
        addprice = (TextView) findViewById(R.id.total_amount);
        showdetails = (TextView)findViewById(R.id.have_order);
    }

    public void countIN(View view){

        increaser++;
        countepuri.setText(Integer.toString(increaser));

        totalpuri = Integer.parseInt(countepuri.getText().toString());
        totalprice = totalpuri*5;
        addprice.setText(String.valueOf(totalprice));
        showdetails.setText("You ordered "+totalpuri+" and Your Bill is "+totalprice+" Tk.");
    }

    public void countDE(View view) {
        increaser--;
        if(increaser<0){
            Toast.makeText(this, "Enter Item", Toast.LENGTH_SHORT).show();
            increaser = 0;
        }else{
            countepuri.setText(Integer.toString(increaser));
            totalpuri = Integer.parseInt(countepuri.getText().toString());
            totalprice = totalpuri*5;
            addprice.setText(String.valueOf(totalprice));
            showdetails.setText("You ordered "+totalpuri+" and Your Bill is "+totalprice+" Tk.");
        }
    }

    public void resetCount(View view){

        increaser=0;
        countepuri.setText(Integer.toString(increaser));
        addprice.setText(Integer.toString(increaser));
        showdetails.setText("You ordered "+increaser+" and Your Bill is "+increaser+" Tk.");
    }

}
