package com.example.shishir.sqliteapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper myDb;
    EditText editName, editSurename, editMarks;
    Button btnAddData;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDb = new DatabaseHelper(this);
        editName = (EditText) findViewById(R.id.edit1);
        editName = (EditText) findViewById(R.id.edit2);
        editName = (EditText) findViewById(R.id.edit3);
        btnAddData = (Button) findViewById(R.id.btnAdd);
        AddData();
    }

    public void AddData(){
        btnAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isInserted = myDb.insertData(editName.getText().toString(),
                        editSurename.getText().toString(),
                        editMarks.getText().toString());

                if(isInserted == true)
                    Toast.makeText(MainActivity.this, "Data Is Inserted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this, "Data Is Not Inserted", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
