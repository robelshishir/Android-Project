package com.example.shishir.downloadmanager;

import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

import java.net.URL;

public class MainActivity extends AppCompatActivity {

    Button button;
    DownloadManager downloadManager;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       button = (Button) findViewById(R.id.button);
       button.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               downloadManager = (DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);
               Uri uri = Uri.parse("https://firebasestorage.googleapis.com/v0/b/smartstudentdiu.appspot.com/o/exam%20questions%20of%20fall%202016.rar?alt=media&token=cca7ef6b-2487-4e61-a5d6-739509b3ec06");
               DownloadManager.Request request = new DownloadManager.Request(uri);
               request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
               Long reference = downloadManager.enqueue(request);

           }
       });
    }

}
